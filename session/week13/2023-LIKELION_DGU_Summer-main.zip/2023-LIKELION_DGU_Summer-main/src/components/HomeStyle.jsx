import { styled } from "styled-components";

// Home Component 관련 styled component

export const Container = styled.div`
  max-width: 100vw;
  display: flex;
  flex-direction: column;
`;
