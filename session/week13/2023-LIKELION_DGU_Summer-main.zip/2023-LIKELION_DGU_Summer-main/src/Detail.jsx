// Detail.jsx

const Detail = () => {
  {
    /* 측정소별 디테일 페이지를 작성해주세요. */
  }
  return <>측정소 디테일 페이지</>;
};

export default Detail;
